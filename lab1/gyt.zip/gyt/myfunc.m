function [sum, product] = myfunc(x,y)
sum = x+y;
product = x*y;