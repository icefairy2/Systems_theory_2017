close all
open('fig1.fig')
open('fig2.fig')
open('fig3.fig')
open('fig4.fig')
open('fig5.fig')
open('fig6.fig')
open('fig7.fig')
open('fig8.fig')